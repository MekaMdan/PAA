Link perfil Spoj:
    - https://www.spoj.com/users/mekamdan/
    - https://www.spoj.com/status/mekamdan/

